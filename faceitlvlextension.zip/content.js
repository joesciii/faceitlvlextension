// An "Immediately Invoked Function Expression" to use async/await
(async () => {
  // --- Helper function to get the 64-bit Steam ID (this stays the same) ---
  const getSteamID64 = () => {
    const url = window.location.href;
    const profileMatch = url.match(/steamcommunity\.com\/profiles\/(\d{17})/);
    if (profileMatch && profileMatch[1]) {
      return profileMatch[1];
    }
    const pageSource = document.documentElement.innerHTML;
    const idMatch = pageSource.match(/"steamid":"(\d{17})"/);
    if (idMatch && idMatch[1]) {
      return idMatch[1];
    }
    return null;
  };

  // --- Helper function to get FACEIT data (UPDATED) ---
  const getFaceitData = async (steamId64) => {
    // The URL of YOUR new serverless function
    const proxyApiUrl = `https://faceitfinderextension.vercel.app/api/faceit-data?steamId=${steamId64}`;
    try {
      // We no longer need the API key here!
      const response = await fetch(proxyApiUrl);
      if (!response.ok) {
        console.error("Proxy Server Error:", response.status, response.statusText);
        return null;
      }
      return await response.json();
    } catch (error) {
      console.error("Failed to fetch from proxy server:", error);
      return null;
    }
  };

  // --- Main logic (UPDATED and simplified) ---
  const steamId = getSteamID64();
  if (!steamId) {
    console.log("Steam ID not found on this page.");
    return;
  }

  // We no longer need to get the key from storage. We just call the function.
  const playerData = await getFaceitData(steamId);

  if (playerData && playerData.games && playerData.games.cs2 && playerData.games.cs2.skill_level) {
    const level = playerData.games.cs2.skill_level;
    const nickname = playerData.nickname;
    const faceitUrl = playerData.faceit_url.replace('{lang}', 'en');

    const targetElement = document.querySelector('.actual_persona_name');
    if (targetElement) {
      const icon = document.createElement('img');
      icon.src = chrome.runtime.getURL(`images/faceit${level}.png`);
      icon.title = `FACEIT Level ${level} (${nickname})`;
      icon.style.width = '24px';
      icon.style.height = '24px';
      icon.style.marginLeft = '8px';
      icon.style.verticalAlign = 'middle';

      const link = document.createElement('a');
      link.href = faceitUrl;
      link.target = '_blank';
      link.appendChild(icon);

      targetElement.insertAdjacentElement('afterend', link);
    }
  } else {
    console.log(`No FACEIT CS2 data found for Steam ID: ${steamId}`);
  }
})();